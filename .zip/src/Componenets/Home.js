import React from 'react'

export default function Home(prop) {
    return (
        <div>
            <center>
                <h1 style={{ color: `${prop.color}` }}>Welcome to Textutils Website</h1>
            </center>
        </div>
    )
}
